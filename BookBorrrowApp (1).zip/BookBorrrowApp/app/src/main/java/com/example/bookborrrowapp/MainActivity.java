package com.example.bookborrrowapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity<bookNames> extends AppCompatActivity implements AdapterView.OnItemClickListener, View.OnClickListener {
  public static   ListView lv;
    TextView title,moreDetail;
    ImageView sImg;

    ArrayList <Book> books=new ArrayList<Book>();
   public static String bookNames[]=new String[6];
 public static    ArrayList <Book> selectedBook=new ArrayList<Book>();//arraylist for spinner formation
    public static String selectedBookTitle;
    public static String selectedBookAuthor;
    public static String selectedBookPub;
    public static int selectedBookPubYr;
    public static int selectedimg;
    public static String bookname;

    public void filldetail(){
        books.add(new Book(": 0133761312.","Java Programming",R.drawable.java," y. daniel liang","Pearson",2013));
        books.add(new Book(":  978-0133950403","Swift PRogramming",R.drawable.swift,"J.D Gauchat"," LearnToProgram",2014));
        books.add(new Book(":  978-0133950403","iOS Development",R.drawable.ios," y. daniel liang","Pearson",2010));
        books.add(new Book(": 0133761312.","Learning Android",R.drawable.android," y. daniel liang","Pearson",2017));
        books.add(new Book(":  978-0133950403","C++",R.drawable.cprogramming," y. daniel liang","Pearson",2018));
        books.add(new Book(":  948-09222250403",".NET Programming",R.drawable.nett," iel piang","Pearson",2016));
       // books.add(new Book(":  978-0133950403",".Net",R.drawable.nett," tsung purooi","Pearson",2018));
        for(int i=0;i<books.size();i++)
            bookNames[i]=books.get(i).getBookTitle();
       for(int j=0;j<books.size();j++)
            bookname=books.get(j).getBookTitle();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        filldetail();//calling the method
        lv=findViewById(R.id.booknoLv);
        title=findViewById(R.id.tvTitle);
        moreDetail=findViewById(R.id.tvMoreDetail);
        sImg=findViewById(R.id.imgSmall);


        //setting the adapter of the list view from the bookadatpter class
        lv.setAdapter(new BookAdapter(this,books));
        lv.setOnItemClickListener(this);
        moreDetail.setOnClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int i, long l) {
if(parent.getId()==R.id.booknoLv){
    title.setText(books.get(i).getBookTitle());
    sImg.setImageResource(books.get(i).getImg());
    selectedBookTitle=books.get(i).getBookTitle();
    selectedimg=books.get(i).getImg();
    selectedBookAuthor=books.get(i).getAuthorName();
    selectedBookPub=books.get(i).getPublisherName();
    selectedBookPubYr=books.get(i).getPubYear();

}

    }

    @Override
    public void onClick(View v) {
      //  for(int i=0;i<books.size();i++)
      //  selectedBookTitle=selectedBook.get(i).getBookTitle();

selectedBookTitle=MainActivity.selectedBookTitle;
selectedimg=MainActivity.selectedimg;
selectedBookAuthor=MainActivity.selectedBookAuthor;
selectedBookPub=MainActivity.selectedBookPub;
selectedBookPubYr=MainActivity.selectedBookPubYr;
        Intent intent = new Intent(this,BookDetailActivity.class);
        startActivity(intent);


    }
}
