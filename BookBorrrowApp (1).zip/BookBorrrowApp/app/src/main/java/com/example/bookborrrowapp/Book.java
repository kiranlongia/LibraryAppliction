package com.example.bookborrrowapp;

public class Book {
    private String isbn;
    private String bookTitle;
    private int img;
    private String authorName;
    private String publisherName;
    private int pubYear;

    public Book(String isbn, String bookTitle, int img, String authorName, String publisherName, int pubYear) {
        this.isbn = isbn;
        this.bookTitle = bookTitle;
        this.img = img;
        this.authorName = authorName;
        this.publisherName = publisherName;
        this.pubYear = pubYear;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public String getPublisherName() {
        return publisherName;
    }

    public void setPublisherName(String publisherName) {
        this.publisherName = publisherName;
    }

    public int getPubYear() {
        return pubYear;
    }

    public void setPubYear(int pubYear) {
        this.pubYear = pubYear;
    }
}
