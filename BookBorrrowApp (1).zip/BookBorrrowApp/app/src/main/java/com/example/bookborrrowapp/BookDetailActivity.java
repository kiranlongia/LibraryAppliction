package com.example.bookborrrowapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class BookDetailActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener {
TextView author,publisher,year,descTitle;
ImageView largeImage;
Button borrow;
ListView lvAdd;

  static  ArrayList<String> addedBooks = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_detail);
        author=findViewById(R.id.tvAuthor);
        publisher=findViewById(R.id.tvPub);
        year=findViewById(R.id.tvYear);
        descTitle=findViewById(R.id.tvTiltle2);
        largeImage=findViewById(R.id.imageView);
          borrow=findViewById(R.id.buttonBorrow);
          lvAdd=findViewById(R.id.lvaddBooks);


        descTitle.setText(MainActivity.selectedBookTitle);
        author.setText(MainActivity.selectedBookAuthor);

        publisher.setText(MainActivity.selectedBookPub);
        year.setText(String.valueOf(MainActivity.selectedBookPubYr));
       largeImage.setImageResource(MainActivity.selectedimg);

       ArrayAdapter listadapter = new ArrayAdapter(this,android.R.layout.simple_list_item_single_choice,addedBooks);
       lvAdd.setAdapter(listadapter);

       borrow.setOnClickListener(this);
       lvAdd.setOnItemClickListener(this);


    }
    @Override

    public void onClick(View v) {


if(addedBooks.size()<4){
if(isAdded(MainActivity.selectedBookTitle)) {
    Toast.makeText(getApplicationContext(), "You have already added this book", Toast.LENGTH_LONG).show();
   // listadapter = new ArrayAdapter(this,android.R.layout.simple_list_item_single_choice,addedBooks);
  //  lvAdd.setAdapter(listadapter);
} else {
    addedBooks.add(MainActivity.selectedBookTitle.toString());

   ArrayAdapter listadapter = new ArrayAdapter(this,android.R.layout.simple_list_item_single_choice,addedBooks);
    lvAdd.setAdapter(listadapter);
}

    }
else{
    Toast.makeText(getApplicationContext(), "You cannot add more books", Toast.LENGTH_LONG).show();

}}
    public Boolean isAdded(String currentBook){

        for(int i =0;i<addedBooks.size();i++)
            if(currentBook.equals(addedBooks.get(i)))
                return true;
        return false; //if no match which means the book is not added yet

    }


   /* public int searchCourse(String courseName){
        for(int i =0;i<MainActivity.bookNames.length;i++)
            if(courseName.equals(MainActivity.bookNames))
                return i;
        return -1;
    }*/


    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
      //  int index = searchCourse(addedBooks.get(i));
        addedBooks.remove(i);
        ArrayAdapter listadapter = new ArrayAdapter(this,android.R.layout.simple_list_item_single_choice,addedBooks);
        lvAdd.setAdapter(listadapter);
    }
}
