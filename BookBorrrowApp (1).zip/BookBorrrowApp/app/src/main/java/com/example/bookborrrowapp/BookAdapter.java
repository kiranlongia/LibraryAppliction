package com.example.bookborrrowapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class BookAdapter extends BaseAdapter {
    private ArrayList<Book> booksData;
    private LayoutInflater layoutInflater;

    public BookAdapter(Context context, ArrayList<Book> booksData){
        this.booksData=booksData;
        layoutInflater=LayoutInflater.from(context);}

    @Override
    public int getCount() {
        return booksData.size();
    }

    @Override
    public Object getItem(int position) {
        return booksData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        ViewHolder holder;
        if(view==null){
            view=layoutInflater.inflate(R.layout.list_row,null);
            holder=new ViewHolder();
            holder.tvBookNo=view.findViewById(R.id.tvNo);

            view.setTag(holder);
        }
        else

            holder=(ViewHolder) view.getTag();
        holder.tvBookNo.setText(booksData.get(position).getIsbn());
        return view;
    }

    static class ViewHolder {
        TextView tvBookNo;

    }



}
